.onAttach <- function(libname, pkgname){
  packageStartupMessage("Bond Lab is a registered trademark of Bond Lab Technologies.")
}

