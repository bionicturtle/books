.onAttach <- function(libname, pkgname){
  packageStartupMessage("Companion to Investing in MBS. Copyright 2015 by John Wiley and Sons, Inc.")
}